load('libs.js');
load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = url.replace("/article/", "/r/");

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');

        let coverImage = `https://www.69yuedu.net/files/article/image/${$.Q(doc, 'div.booknav2 > h1 > a').attr('href').match(/\/article\/(\d+)\.html/)[1]}/cover.jpg`;

        return Response.success({
            name: $.Q(doc, 'div.booknav2 > h1 > a').text().trim(),
            cover: coverImage,
            author: $.Q(doc, 'div.booknav2 > p > a').text().trim(),
            description: $.Q(doc, 'div.navtxt > p').text().trim(),
            host: BASE_URL
        });
    }

    return null;
}
