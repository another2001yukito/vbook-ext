load('libs.js');
load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = url.replace("/article/", "/r/");

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');

        let coverImage = `https://www.69yuedu.net/files/article/image/${$.Q(doc, 'div.booknav2 > h1 > a').attr('href').match(/\/article\/(\d+)\.html/)[1]}/cover.jpg`;

        return Response.success({
            name: $.Q(doc, 'div.booknav2 > h1 > a').text().trim(),
            cover: coverImage,
            author: $.Q(doc, 'div.booknav2 > p > a').text().trim(),
            category: $.Q(doc, 'div.booknav2 > p > a[title]').text().trim(),
            wordCount: $.Q(doc, 'div.booknav2 > p').text().match(/(\d+\.\d+)万字/)[1],
            status: $.Q(doc, 'div.booknav2 > p').text().includes("连载") ? "Ongoing" : "Completed",
            lastUpdated: $.Q(doc, 'div.booknav2 > p').text().match(/更新：(\d{4}-\d{2}-\d{2})/)[1],
            description: $.Q(doc, 'div.navtxt > p').text().trim(),
            host: BASE_URL
        });
    }

    return null;
}
