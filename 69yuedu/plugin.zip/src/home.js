function execute() {
    return Response.success([
        {title: "新书", input: "/articlelist/newhot_0_0_1.html", script: "gen.js"},
        {title: "全部分类", input: "/articlelist/class/0.html", script: "gen.js"},
        {title: "言情小说", input: "/articlelist/class/3.html", script: "gen.js"},
        {title: "玄幻魔法", input: "/articlelist/class/1.html", script: "gen.js"},
        {title: "修真武侠", input: "/articlelist/class/2.html", script: "gen.js"},
        {title: "穿越时空", input: "/articlelist/class/11.html", script: "gen.js"},
        {title: "都市小说", input: "/articlelist/class/9.html", script: "gen.js"},
        {title: "历史军事", input: "/articlelist/class/4.html", script: "gen.js"},
        {title: "游戏竞技", input: "/articlelist/class/5.html", script: "gen.js"},
        {title: "科幻空间", input: "/articlelist/class/6.html", script: "gen.js"},
        {title: "悬疑惊悚", input: "/articlelist/class/7.html", script: "gen.js"},
        {title: "同人小说", input: "/articlelist/class/8.html", script: "gen.js"},
        {title: "官场职场", input: "/articlelist/class/10.html", script: "gen.js"},
        {title: "青春校园", input: "/articlelist/class/12.html", script: "gen.js"},
    ]);
}
