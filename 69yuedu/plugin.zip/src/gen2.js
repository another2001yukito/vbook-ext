load('libs.js');
load('config.js');

function execute(url, page = '1') {
    url = String.format(BASE_URL + "/articlelist/tag/" + url + (page === '1' ? '/' : '/' + page + '/'));
    console.log(url);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        let data = [];

        $.QA(doc, 'div.newnav').forEach(function(e) {
            let articleLink = $.Q(e, 'h3 > a').attr('href');
            let bookId = articleLink ? articleLink.match(/\/article\/(\w+)\.html/)[1] : '';
            data.push({
                name: $.Q(e, 'h3 > a').text().trim(),
                link: articleLink,
                cover: bookId ? `https://www.69yuedu.net/files/article/image/${bookId}/cover.jpg` : '',
                description: $.Q(e, '.ellipsis_2').text().replace('简介：', '').trim(),
                latestChapter: $.Q(e, '.zxzj > p').text().trim(),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }

    return null;
}
