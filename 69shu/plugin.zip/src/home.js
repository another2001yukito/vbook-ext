// home.js — Trang khám phá
// Dựa trên cấu trúc thực tế: /novels/monthvisit_X_0_{page}.htm
// Trang danh sách dùng script genlist.js

function execute() {
    return Response.success([
        { title: "全部",     input: "/novels/monthvisit_0_0_{0}.htm",  script: "genlist.js" },
        { title: "玄幻魔法", input: "/novels/monthvisit_1_0_{0}.htm",  script: "genlist.js" },
        { title: "修真武侠", input: "/novels/monthvisit_2_0_{0}.htm",  script: "genlist.js" },
        { title: "言情小说", input: "/novels/monthvisit_3_0_{0}.htm",  script: "genlist.js" },
        { title: "历史军事", input: "/novels/monthvisit_4_0_{0}.htm",  script: "genlist.js" },
        { title: "游戏竞技", input: "/novels/monthvisit_5_0_{0}.htm",  script: "genlist.js" },
        { title: "科幻空间", input: "/novels/monthvisit_6_0_{0}.htm",  script: "genlist.js" },
        { title: "悬疑惊悚", input: "/novels/monthvisit_7_0_{0}.htm",  script: "genlist.js" },
        { title: "同人小说", input: "/novels/monthvisit_8_0_{0}.htm",  script: "genlist.js" },
        { title: "都市小说", input: "/novels/monthvisit_9_0_{0}.htm",  script: "genlist.js" },
        { title: "官场职场", input: "/novels/monthvisit_10_0_{0}.htm", script: "genlist.js" },
        { title: "穿越时空", input: "/novels/monthvisit_11_0_{0}.htm", script: "genlist.js" },
        { title: "青春校园", input: "/novels/monthvisit_12_0_{0}.htm", script: "genlist.js" }
    ]);
}
