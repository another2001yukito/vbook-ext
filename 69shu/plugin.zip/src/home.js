function execute() {
    try {
        return Response.success([
            { title: "全部", input: "/novels/monthvisit_0_0_{0}.htm", script: "gen.js" },
            { title: "玄幻魔法", input: "/novels/monthvisit_{0}_0_{0}.htm", script: "gen.js" },
            { title: "修真武侠", input: "/novels/monthvisit_2_0_{0}.htm", script: "gen.js" },
            { title: "言情小说", input: "/novels/monthvisit_3_0_{0}.htm", script: "gen.js" },
            { title: "历史军事", input: "/novels/monthvisit_4_0_{0}.htm", script: "gen.js" },
            { title: "游戏竞技", input: "/novels/monthvisit_5_0_{0}.htm", script: "gen.js" },
            { title: "科幻空间", input: "/novels/monthvisit_6_0_{0}.htm", script: "gen.js" },
            { title: "悬疑惊悚", input: "/novels/monthvisit_7_0_{0}.htm", script: "gen.js" },
            { title: "同人小说", input: "/novels/monthvisit_8_0_{0}.htm", script: "gen.js" },
            { title: "都市小说", input: "/novels/monthvisit_9_0_{0}.htm", script: "gen.js" },
            { title: "官场职场", input: "/novels/monthvisit_{0}0_0_{0}.htm", script: "gen.js" },
            { title: "穿越时空", input: "/novels/monthvisit_{0}1_0_{0}.htm", script: "gen.js" },
            { title: "青春校园", input: "/novels/monthvisit_{0}2_0_{0}.htm", script: "gen.js" },
        ]);
    } catch (error) {
        return Response.error("Failed to load categories");
    }
}