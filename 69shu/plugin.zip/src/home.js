function execute() {
    try {
        return Response.success([
            { title: "小说排行", input: "/novels/full/0/{0}.htm", script: "gen.js" },
            { title: "言情小说排行", input: "/novels/full/3/{0}.htm", script: "gen.js" },
            { title: "玄幻小说排行", input: "/novels/full/1/{0}.htm", script: "gen.js" },
            { title: "修真小说排行", input: "/novels/full/2/{0}.htm", script: "gen.js" },
            { title: "穿越小说排行", input: "/novels/full/11/{0}.htm", script: "gen.js" },
            { title: "都市小说排行", input: "/novels/full/9/{0}.htm", script: "gen.js" },
            { title: "历史小说排行", input: "/novels/full/4/{0}.htm", script: "gen.js" },
            { title: "游戏小说排行", input: "/novels/full/5/{0}.htm", script: "gen.js" },
            { title: "科幻小说排行", input: "/novels/full/6/{0}.htm", script: "gen.js" },
            { title: "悬疑小说排行", input: "/novels/full/7/{0}.htm", script: "gen.js" },
            { title: "同人小说排行", input: "/novels/full/8/{0}.htm", script: "gen.js" },
            { title: "官场小说排行", input: "/novels/full/10/{0}.htm", script: "gen.js" },
            { title: "青春小说排行", input: "/novels/full/12/{0}.htm", script: "gen.js" },
            { title: "全部", input: "/novels/monthvisit_0_0_{0}.htm", script: "gen.js" },
            { title: "玄幻魔法", input: "/novels/monthvisit_{0}_0_{0}.htm", script: "gen.js" },
            { title: "修真武侠", input: "/novels/monthvisit_2_0_{0}.htm", script: "gen.js" },
            { title: "言情小说", input: "/novels/monthvisit_3_0_{0}.htm", script: "gen.js" },
            { title: "历史军事", input: "/novels/monthvisit_4_0_{0}.htm", script: "gen.js" },
            { title: "游戏竞技", input: "/novels/monthvisit_5_0_{0}.htm", script: "gen.js" },
            { title: "科幻空间", input: "/novels/monthvisit_6_0_{0}.htm", script: "gen.js" },
            { title: "悬疑惊悚", input: "/novels/monthvisit_7_0_{0}.htm", script: "gen.js" },
            { title: "同人小说", input: "/novels/monthvisit_8_0_{0}.htm", script: "gen.js" },
            { title: "都市小说", input: "/novels/monthvisit_9_0_{0}.htm", script: "gen.js" },
            { title: "官场职场", input: "/novels/monthvisit_{0}0_0_{0}.htm", script: "gen.js" },
            { title: "穿越时空", input: "/novels/monthvisit_{0}1_0_{0}.htm", script: "gen.js" },
            { title: "青春校园", input: "/novels/monthvisit_{0}2_0_{0}.htm", script: "gen.js" },
        ]);
    } catch (error) {
        return Response.error("Failed to load categories");
    }
}