load('libs.js');
load('config.js');

function execute(url, page) {
    page = page || '1';
    url = String.format(BASE_URL + url, page);
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        let data = [];
        let elems = $.QA(doc, 'li');

        elems.forEach(function(e) {
            let name = $.Q(e, '.newnav h3 > a').text().trim();
            let link = $.Q(e, 'h3 > a').attr('href');
            let cover = $.Q(e, '.imgbox > img').attr('data-src').trim();
            let description = $.Q(e, '.zxzj > p').text().replace('最近章节', '').replace(/第(\d+)章/, "第$1章:").replace(/(?:\d+\.)?第(\d+)章(?:\s*\d+)?/, "第$1章");

            if (name && link && link.startsWith('http')) {
                data.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }
        });

        return Response.success(data, (parseInt(page) + 1).toString());
    }
    return null;
}