load('libs.js');
load('config.js');

function execute(url, page) {
    page = page || '1';
    url = String.format(BASE_URL + url, page);
    console.log(url)
    // log(url);
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        let coverLink = $.Q(doc, 'div.booknav2 > h1 > a').attr('href');
        let bookId = coverLink.match(/\/book\/(\d+)\.htm/);
        let coverImage = bookId ? `https://69shuba.cx/fengmian/${bookId[1].slice(0, 2)}/${bookId[1]}/${bookId[1]}s.jpg` : '';
        var data = [];
        var elems = $.QA(doc, 'li');
        if (!elems.length) return Response.error(url);
        elems.forEach(function(e) {
            data.push({
                name: $.Q(e, '.newnav h3 > a:not([class])').text().trim(),
                link: $.Q(e, 'h3 > a').attr('href'),
                cover: coverImage,
                description: $.Q(e, '.zxzj > p').text().replace('最近章节', ''),
                host: BASE_URL
            })
        })
        var next = parseInt(page, 10) + 1;
        return Response.success(data, next.toString());
    }
    return null;
}
