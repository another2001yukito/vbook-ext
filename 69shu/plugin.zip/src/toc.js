load('libs.js');
load('config.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function execute(url) {
    let domain = url.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/i);
    if (!domain) return Response.error("Invalid URL");

    domain = "https://" + domain[1];

    if (!BASE_URLS.includes(domain)) return Response.error("Unsupported source");

    url = url.replace(domain, BASE_URL);

    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);
    if (!match) return Response.error("Invalid book URL format");

    let book_id = match[1];
    console.log("Book ID:", book_id);

    let response = fetch(`${BASE_URL}/book/${book_id}/`);
    if (response.ok) {
        let doc = response.html('gbk');

        var data = [];
        var elems = $.QA(doc, 'div.catalog > ul > li > a:not(#bookcase)');
        
        elems.forEach(function(e) {
            data.push({
                name: formatName(e.text()),
                url: e.attr('href').replace(domain, BASE_URL),
                host: BASE_URL
            });
        });

        data.reverse();

        return Response.success(data);
    }

    return Response.error("Failed to fetch data");
}

// "63.第63章 无上极境，诸神共鸣" --> "第63章 无上极境，诸神共鸣"
function formatName(name) {
    var re = /^(\d+)\.第(\d+)章/;
    return name.replace(re, '第$2章');
}
