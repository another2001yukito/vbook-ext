// toc.js — Lấy mục lục chương
//
// Cấu trúc HTML thực tế (trang /book/XXXXX/):
// Có 2 div.catalog trên trang:
//   - div.catalog #1: chỉ có 1 <li> dummy là bookcase widget → bỏ qua
//   - div.catalog #2: chứa 431+ <li> thật với toàn bộ chương
//
// Cấu trúc mỗi <li>:
//   <li data-num="530">
//     <a href="https://www.69shuba.com/txt/90442/41034168">第530章 ...</a>
//   </li>
//
// Lưu ý:
//   - Trang trả về chương theo thứ tự MỚI NHẤT trước → dùng push (không unshift)
//     để giữ nguyên thứ tự đó, app thường hiển thị từ mới nhất.
//   - href là full URL → chỉ trả về path (bỏ domain) kèm host riêng.

load('config.js');
load('libs.js');

function execute(url) {
    var bookId = extractBookId(url);
    if (!bookId) return Response.error('Cannot extract book ID from: ' + url);

    var tocUrl = BASE_URL + '/book/' + bookId + '/';

    var response = fetch(tocUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    if (!response.ok) return Response.error('Fetch failed: ' + tocUrl);

    var doc = response.html('gbk');

    // Lấy TẤT CẢ div.catalog, chọn cái có nhiều <li> nhất (cái thật)
    var catalogs = $.QA(doc, 'div.catalog');
    var targetUl = null;
    var maxLi = 0;

    catalogs.forEach(function(cat) {
        var uls = $.QA(cat, 'ul');
        uls.forEach(function(ul) {
            var lis = $.QA(ul, 'li');
            if (lis.length > maxLi) {
                maxLi = lis.length;
                targetUl = ul;
            }
        });
    });

    if (!targetUl || maxLi === 0) {
        return Response.error('Chapter list not found (book ID: ' + bookId + ')');
    }

    var data = [];
    var lis = $.QA(targetUl, 'li');

    lis.forEach(function(li) {
        var a = $.Q(li, 'a');
        var href = a.attr('href');
        var name = a.text().trim();

        // Bỏ qua li dummy (href="#" hoặc rỗng)
        if (!href || href === '#' || !name) return;

        // Chỉ giữ path, bỏ domain
        var path = toPath(href);

        // Trang trả về chương theo thứ tự MỚI NHẤT trước (chương 530, 529, ...)
        // Dùng unshift để đảo lại → chương 1 ở đầu, đọc từ đầu đến cuối
        data.unshift({
            name: formatChapterName(name),
            url:  path,
            host: BASE_URL
        });
    });

    if (!data.length) return Response.error('No valid chapters found');

    return Response.success(data);
}

// Extract book ID từ nhiều dạng URL:
//   /book/90442.htm  →  90442
//   /book/90442/     →  90442
//   /txt/90442/...   →  90442
function extractBookId(url) {
    var m = url.match(/\/(?:book|txt)\/(\d+)/);
    return m ? m[1] : null;
}
