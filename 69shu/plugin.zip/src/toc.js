load('libs.js');
load('config.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function execute(url) {
    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);
    if (!match) return Response.error("Invalid URL format");

    let book_id = match[1];

    let domain = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/]+)/i);
    if (!domain) return Response.error("Invalid domain");

    domain = "https://" + domain[1];
    if (!BASE_URLS.includes(domain)) return Response.error("Unsupported source");

    let BASE_URL = BASE_URLS[0];

    console.log("Fetching: " + BASE_URL + "/book/" + book_id + "/");

    let response = fetch(BASE_URL + "/book/" + book_id + "/");
    if (!response.ok) return Response.error("Failed to fetch book data");

    let doc = response.html('gbk');

    var data = [];
    var elems = $.QA(doc, 'div.catalog > ul > li > a:not(#bookcase)');

    elems.forEach(function(e) {
        data.unshift({
            name: formatName(e.text()),
            url: e.attr('href'),
            host: BASE_URL
        });
    });

    return Response.success(data);
}

function formatName(name) {
    return name.replace(/^(\d+)\.第(\d+)章/, '第$2章');
}
