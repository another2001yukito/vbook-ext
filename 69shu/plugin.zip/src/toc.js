load('libs.js');
load('config.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function getAvailableBaseUrl() {
    for (let url of BASE_URLS) {
        let response = fetch(url + "/favicon.ico");
        if (response.ok) return url;
    }
    return BASE_URLS[0];
}

const BASE_URL = getAvailableBaseUrl();

function execute(url) {
    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);

    if (!match) return Response.error("URL không hợp lệ");

    let book_id = match[1];
    let response = fetch(BASE_URL + "/book/" + book_id + "/");

    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];
        var elems = $.QA(doc, 'div.catalog > ul > li > a:not(#bookcase)');

        elems.forEach(function(e) {
            data.push({
                name: formatName(e.text()),
                url: e.attr('href'),
                host: BASE_URL
            });
        });

        return Response.success(data.reverse());
    }
    return null;
}

function formatName(name) {
    var re = /^(\d+)\.第(\d+)章/;
    return name.replace(re, '第$2章');
}
