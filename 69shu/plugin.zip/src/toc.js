load('libs.js');
load('config.js');

function execute(url) {
    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);

    if (!match) {
        console.log("Invalid URL format: " + url);
        return Response.error("Invalid URL format");
    }

    let book_id = match[1];
    console.log("Fetching book ID: " + book_id);

    let response = fetch(BASE_URL + "/book/" + book_id + "/");
    if (response.ok) {
        let doc = response.html('gbk');

        var data = [];
        var elems = $.QA(doc, 'div.catalog > ul > li > a:not(#bookcase)');

        if (!elems.length) {
            console.log("No chapters found for book ID: " + book_id);
            return Response.error("No chapters found");
        }

        elems.forEach(function(e) {
            let chapterUrl = e.attr('href');
            if (!chapterUrl.startsWith('http')) {
                chapterUrl = BASE_URL + chapterUrl;
            }

            data.push({
                name: formatName(e.text().trim()),
                url: chapterUrl,
                host: BASE_URL
            });
        });

        return Response.success(data.reverse());
    }
    return Response.error("Failed to fetch book data");
}

// "63.第63章 无上极境，诸神共鸣" --> "第63章 无上极境，诸神共鸣"
function formatName(name) {
    return name.replace(/^(\d+)\.第(\d+)章/, '第$2章');
}
