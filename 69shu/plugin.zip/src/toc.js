load('libs.js');
load('config.js');

function execute(url) {
    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);
    if (!match) return null;

    let book_id = match[1];
    console.log("Book ID:", book_id);

    let book_url = BASE_URL + "/book/" + book_id + "/";
    let response = fetch(book_url);

    if (response.ok) {
        let doc = response.html('gbk');

        var data = [];
        var elems = $.QA(doc, 'div.catalog > ul > li > a:not(#bookcase)');

        elems.forEach(function(e) {
            data.push({
                name: formatName(e.text()),
                url: resolveUrl(BASE_URL, e.attr('href')),
                host: BASE_URL
            });
        });

        data = data.reverse();
        return Response.success(data);
    }
    return null;
}

function formatName(name) {
    var re = /^(\d+)\.第(\d+)章/;
    return name.replace(re, '第$2章');
}

function resolveUrl(base, relative) {
    if (relative.startsWith('http')) return relative;
    return base.replace(/\/$/, '') + '/' + relative.replace(/^\//, '');
}
