load('libs.js');
load('config.js');

function execute(url, page) {
    page = page || '1';
    url = String.format(BASE_URL + "/blist/tag/" + url + (page === '1' ? '' : '/' + page));
    console.log(url);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];
        var elems = doc.select("ul#article_list_content li");

        elems.forEach(function(e) {
            data.push({
                name: e.select("h3").text().trim() || "Unknown Title",
                link: e.select("h3 a").attr('href') || "",
                cover: e.select("img").attr('data-src') 
                    ? e.select("img").attr('data-src').trim().replace('image', 'fengmian') 
                    : null,
                description: e.select(".zxzj > p").text().trim().replace('最近章节', '') || "No description",
                host: BASE_URL
            });
        });

        let next = parseInt(page, 10) + 1;
        return Response.success(data, next.toString());
    }
    return null;
}