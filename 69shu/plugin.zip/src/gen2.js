load('libs.js');
load('config.js');

function execute(url, page) {
    page = page || '1';
    url = String.format(BASE_URL + "/blist/tag/" + url + (page === '1' ? '/' : '/' + page + '/'));

    console.log("Fetching URL: " + url);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];
        var elems = $.QA(doc, '.newnav');

        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            let bookLink = $.Q(e, 'h3 > a').attr('href');
            let bookIdMatch = bookLink ? bookLink.match(/(\d+)\.htm/) : null;
            let bookId = bookIdMatch ? bookIdMatch[1] : null;
            let coverUrl = bookId ? String.format('{0}/fengmian/{1}/{2}/{2}s.jpg', BASE_URL, Math.floor(bookId / 1000), bookId) : '';

            data.push({
                name: $.Q(e, 'h3 > a').text().trim(),
                link: bookLink.startsWith('http') ? bookLink : BASE_URL + bookLink,
                cover: coverUrl,
                description: $.Q(e, '.ellipsis_2').text().trim() || "No description available",
                host: BASE_URL
            });
        });

        var next = parseInt(page, 10) + 1;
        return Response.success(data, next.toString());
    }
    return null;
}
