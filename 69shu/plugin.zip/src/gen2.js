load('libs.js'); 
load('config.js');

function execute(url, page) {
    page = page || '1';
    url = String.format(BASE_URL + url, page);

    console.log(url);

    let response = fetch(url);

    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'li');

        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            let name = $.Q(e, '.newnav h3 > a:not([class])').text().trim();
            let link = $.Q(e, 'h3 > a').attr('href');
            let cover = $.Q(e, '.imgbox > img').attr('data-src').trim();
            let description = $.Q(e, '.zxzj > p').text().replace('最近章节', '').replace(/第(\d+)章/, "第$1章:").replace(/(?:\d+\.)?第(\d+)章(?:\s*\d+)?/, "第$1章");

            if (name && link && link.startsWith('http')) {
                data.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }
        });

        var next = parseInt(page, 10) + 1;
        return Response.success(data, next.toString());
    }

    return null;
}