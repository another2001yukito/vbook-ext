load('config.js');
load('libs.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function execute(url) {
    var domain = url.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/i);
    if (!domain) return Response.error("Invalid URL");

    domain = "https://" + domain[1];

    if (!BASE_URLS.includes(domain)) return Response.error("Unsupported source");

    url = url.replace(domain, BASE_URL);  

    var browser = Engine.newBrowser();
    var doc = browser.launch(url, 4000);
    browser.close();

    var htm = doc.select(".txtnav");
    htm.select(".contentadv").remove();
    htm.select(".bottom-ad").remove();
    htm.select(".txtinfo").remove();
    htm.select("#txtright").remove();
    htm.select("h1").remove();

    htm = htm.html();
    htm = cleanHtml(htm)
        .replace(/^第\d+章.*?<br>/, '')
        .replace('(本章完)', '');

    return Response.success(htm);
}
