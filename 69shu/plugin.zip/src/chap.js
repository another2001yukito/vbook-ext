load('config.js');
load('libs.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function getAvailableBaseUrl() {
    for (let url of BASE_URLS) {
        let response = fetch(url + "/favicon.ico");
        if (response.ok) return url;
    }
    return BASE_URLS[0];
}

const BASE_URL = getAvailableBaseUrl();

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');

        if (doc.html().includes("69shubaV1")) {
            var browser = Engine.newBrowser();
            doc = browser.launch(url, 4000);
        }

        var htm = doc.select(".txtnav");

        htm.select(".contentadv, .bottom-ad, .txtinfo, #txtright, h1").remove();

        htm = cleanHtml(htm.html())
            .replace(/^第\d+章.*?<br>/, '')
            .replace('(本章完)', '')
            .trim();

        return Response.success(htm);
    }
    return Response.error("Không thể tải chương: " + url);
}
