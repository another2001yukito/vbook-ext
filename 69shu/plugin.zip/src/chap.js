// chap.js — Lấy nội dung chương
//
// URL chương có dạng: /txt/90442/41034168  (path từ toc.js)
//
// Cấu trúc HTML thực tế (div.txtnav):
//   <h1 class="hide720">Tiêu đề chương</h1>
//   <div class="txtinfo hide720">Ngày | Tác giả</div>
//   <div id="txtright">Quảng cáo JS</div>
//   [TEXT NỘI DUNG XEN KẼ CÁC <br>]
//   <div class="contentadv">Quảng cáo giữa/cuối</div>
//   [TEXT TIẾP THEO]
//
// Cần xoá: h1, .txtinfo, #txtright, .contentadv
// Giữ lại: toàn bộ text node và <br> còn lại

load('config.js');
load('libs.js');

function execute(url) {
    if (!url.startsWith('http')) {
        url = BASE_URL + (url.startsWith('/') ? url : '/' + url);
    }

    var response = fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    var doc;
    if (!response.ok) {
        var browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.android());
        doc = browser.launch(url, 5000);
        browser.close();
        if (!doc || doc.html().length < 200) {
            return Response.error('Load failed: ' + url);
        }
    } else {
        doc = response.html('gbk');
    }

    // Selector chính xác nhận từ HTML thực tế
    var block = doc.select('.txtnav');
    if (!block || block.html().trim() === '') {
        block = doc.select('.txtbox, #content, .chapter_content');
        if (!block || block.html().trim() === '') {
            return Response.error('Content block not found: ' + url);
        }
    }

    // Xoá phần không phải nội dung (xác nhận từ HTML thực tế)
    block.select('h1').remove();
    block.select('.txtinfo, .hide720').remove();
    block.select('#txtright').remove();
    block.select('.contentadv, .bottom-ad, .bottom-ad2').remove();
    block.select('.ad, .ads, .adsbygoogle').remove();
    block.select('.share, .chapter_nav, .copyright, .qr, .report').remove();

    var content = cleanHtml(block.html())
        // Xoá tiêu đề chương còn sót dạng text node (không nằm trong thẻ)
        .replace(/^[\s\u2003]*第\d+章[^<]*(<br>)?/m, '')
        .replace(/（本章完）|\(本章完\)/g, '')
        .trim();

    if (!content || content.length < 50) {
        return Response.error('Content too short: ' + url);
    }

    return Response.success(content);
}
