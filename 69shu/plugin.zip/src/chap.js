load('config.js');
load('libs.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html('gbk');

    if (doc.html().includes("69shubaV1")) {
        let browser = Engine.newBrowser();
        doc = browser.launch(url, 4000);
    }

    let htm = doc.select(".txtnav");
    htm.select("h1").remove();
    htm.select(".txtinfo").remove();
    htm.select("#txtright").remove();
    htm.select(".contentadv").remove();
    htm.select(".bottom-ad").remove();
    htm.select(".bottom-ad2").remove();

    let content = htm.html();
    content = cleanHtml(content)
        .replace(/^第\d+章.*?<br\s*\/?>/i, '')
        .replace('(本章完)', '')
        .trim();

    return Response.success(content);
}