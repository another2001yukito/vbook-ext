load('config.js');
load('libs.js');

function execute(url) {
    if (!url.startsWith(BASE_URL)) {
        url = url.replace(/^\/+/, '');
        if (!url.startsWith("txt/")) {
            url = "txt/" + url;
        }
        url = BASE_URL + "/" + url;
    }

    let response = fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Mobile; Safari/537.36)' }
    });

    let doc = null;

    if (!response.ok) {
        let browser = Engine.newBrowser();
        doc = browser.launch(url, 4000);
        if (!doc || doc.html().length < 100) return Response.error("Load failed (browser fallback)");
    } else {
        doc = response.html('gbk');
    }

    let htm = doc.select(".txtnav, .txtbox, #content, .chapter_content");
    if (!htm || htm.html().trim() === '') {
        return Response.error("Empty content block");
    }

    htm.select("h1").remove();
    htm.select(".txtinfo").remove();
    htm.select("#txtright, .contentadv, .bottom-ad, .bottom-ad2").remove();
    htm.select(".ad, .ads, .adsbygoogle, .share, .nav, .footer, .chapter_nav, .copyright, .qr, .report").remove();

    let content = cleanHtml(htm.html())
        .replace(/^第\d+章.*?<br>/, '')
        .replace('(本章完)', '')
        .trim();

    if (!content || content.length < 50) {
        return Response.error("Content too short or empty");
    }

    return Response.success(content);
}