//    var host = 'https://www.69shuba.com';
let BASE_URL = typeof CONFIG_URL !== "undefined" ? CONFIG_URL : 'https://69shuba.cx';

const FALLBACK_URLS = ['https://69shuba.com', 'https://69shuba.me'];

for (let url of FALLBACK_URLS) {
    if (isURLAvailable(url)) {
        BASE_URL = url;
        break;
    }
}

async function isURLAvailable(url) {
    try {
        let response = await fetch(url, { method: 'HEAD', mode: 'no-cors' });
        return response.ok;
    } catch {
        return false;
    }
}

console.log("BASE_URL hiện tại:", BASE_URL);
