//    var host = 'https://www.69shuba.com';
let BASE_URLS = ['https://69shuba.cx', 'https://69shuba.com', 'https://69shuba.me'];
let BASE_URL = BASE_URLS[0];

try {
    if (typeof CONFIG_URL !== "undefined") {
        BASE_URL = CONFIG_URL;
    } else {
        for (let url of BASE_URLS) {
            if (isURLAvailable(url)) {
                BASE_URL = url;
                break;
            }
        }
    }
} catch (error) {
    console.warn("Lỗi khi xác định BASE_URL:", error);
}
async function isURLAvailable(url) {
    try {
        let response = await fetch(url, { method: 'HEAD', mode: 'no-cors' });
        return response.ok;
    } catch {
        return false;
    }
}

console.log("BASE_URL được chọn:", BASE_URL);
