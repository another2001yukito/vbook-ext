//    var host = 'https://www.69shuba.com';
let BASE_URL = 'https://69shuba.cx';

try {
    if (typeof CONFIG_URL !== "undefined" && CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    } else {
        let domains = ['https://69shuba.cx', 'https://www.69shuba.com'];

        for (let domain of domains) {
            let response = fetch(domain, { method: "HEAD" });
            if (response.ok) {
                BASE_URL = domain;
                break;
            }
        }
    }
} catch (error) {
    console.log("Error setting BASE_URL:", error);
}
