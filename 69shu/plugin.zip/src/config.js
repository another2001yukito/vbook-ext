let BASE_URL = 'https://www.69shuba.me';

function isValidURL(url) {
    return url === 'https://www.69shuba.me' ||
           url === 'https://69shuba.cx' ||
           url === 'https://www.69shuba.com';
}

try {
    if (typeof CONFIG_URL !== 'undefined' && isValidURL(CONFIG_URL)) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {}
