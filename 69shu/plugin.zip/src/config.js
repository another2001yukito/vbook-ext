//    var host = 'https://www.69shuba.com';
let BASE_URLS = ['https://69shuba.cx', 'https://69shuba.com', 'https://69shuba.me'];
let BASE_URL = BASE_URLS[0];

try {
    if (typeof CONFIG_URL !== "undefined") {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
    console.warn("CONFIG_URL không hợp lệ:", error);
}

console.log("BASE_URL được chọn:", BASE_URL);
