let BASE_URL = 'https://69shuba.cx';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {}

const ALLOWED_DOMAINS = [
    'https://69shuba.cx',
    'https://69shuba.me',
    'https://69shuba.com'
];

if (!ALLOWED_DOMAINS.includes(BASE_URL)) {
    BASE_URL = 'https://69shuba.cx';
}

