// Base URL — có thể override từ bên ngoài qua CONFIG_URL
var BASE_URL = 'https://www.69shuba.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (e) {}
