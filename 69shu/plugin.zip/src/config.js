let BASE_URL = 'https://69shuba.cx';
const ADDITIONAL_URL = 'https://www.69shuba.com';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

if (someCondition) {
    BASE_URL = ADDITIONAL_URL;
}
