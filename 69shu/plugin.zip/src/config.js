let BASE_URL = "https://69shuba.cx";

try {
    if (typeof CONFIG_URL !== "undefined" && CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    } else if (typeof globalThis !== "undefined" && globalThis.location) {
        const host = globalThis.location.hostname.toLowerCase();

        if (host.includes("69shuba.com")) {
            BASE_URL = "https://www.69shuba.com";
        } else if (host.includes("69shuba.me")) {
            BASE_URL = "https://www.69shuba.me";
        } else if (host.includes("69yuedu.net")) {
            BASE_URL = "https://www.69yuedu.net";
        }
    }
} catch (error) {
}