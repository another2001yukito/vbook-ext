//    var host = 'https://www.69shuba.com';
let BASE_URL = 'https://69shuba.cx';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
    let backup_urls = ['https://69shuba.me', 'https://69shuba.com'];

    for (let url of backup_urls) {
        let response = fetch(url, { method: "HEAD" });
        if (response.ok) {
            BASE_URL = url;
            break;
        }
    }
}

