//    var host = 'https://www.69shuba.com';
const CONFIG_URL = [
    "https://www.69shuba.com",
    "https://69shuba.cx",
    "https://69shuba.me"
];

let BASE_URL = CONFIG_URL[0];

try {
    if (CONFIG_URL && CONFIG_URL.length > 0) {
        BASE_URL = CONFIG_URL[1];
    }
} catch (error) {
    console.error("Lỗi khi cập nhật BASE_URL:", error);
}

console.log("BASE_URL hiện tại:", BASE_URL);
