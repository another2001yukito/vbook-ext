// String.format("{0}", val) helper
if (!String.format) {
    String.format = function(format) {
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/\{(\d+)\}/g, function(match, number) {
            return typeof args[number] !== 'undefined' ? args[number] : match;
        });
    };
}

String.prototype.rtrim = function(s) {
    if (s === undefined) s = '\\s';
    return this.replace(new RegExp('[' + s + ']*$'), '');
};

String.prototype.ltrim = function(s) {
    if (s === undefined) s = '\\s';
    return this.replace(new RegExp('^[' + s + ']*'), '');
};

// ---- DOM helpers ----

var $ = {
    // Trả về element đầu tiên khớp selector, hoặc element rỗng
    Q: function(e, q) {
        var empty = Html.parse('').select('body');
        var els = e.select(q);
        if (!els || els.size() === 0) return empty;
        return els.first();
    },

    // Trả về mảng các element khớp selector
    QA: function(e, q) {
        var arr = [];
        var els = e.select(q);
        if (!els || els.size() === 0) return arr;
        for (var i = 0; i < els.size(); i++) {
            arr.push(els.get(i));
        }
        return arr;
    }
};

// ---- HTML cleaner dùng cho nội dung chương ----
function cleanHtml(html) {
    html = html.replace(/\n/g, '<br>');
    html = html.replace(/(<br>\s*){2,}/gm, '<br>');
    html = html.replace(/<!--[^>]*-->/gm, '');
    html = html.replace(/&nbsp;/g, '');
    html = html.replace(/(^(\s*<br>\s*)+|(<br>\s*)+$)/gm, '');
    return html.trim();
}

// ---- Chuẩn hóa tên chương ----
// "63.第63章 无上极境" → "第63章 无上极境"
function formatChapterName(name) {
    return name.replace(/^\d+\.第(\d+)章/, '第$1章').trim();
}

// ---- Extract path từ URL (bỏ domain) ----
function toPath(url) {
    if (!url) return '';
    if (url.startsWith('http')) {
        // bỏ scheme + host
        var m = url.match(/^https?:\/\/[^\/]+(\/.*)/);
        return m ? m[1] : url;
    }
    return url;
}

// ---- Build cover URL từ book ID ----
function coverUrl(bookId) {
    var id = String(bookId);
    var prefix = id.substring(0, 2);
    return 'https://cdn.cdnshu.com/files/article/image/' + prefix + '/' + id + '/' + id + 's.jpg';
}
