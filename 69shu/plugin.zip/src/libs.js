// https://stackoverflow.com/a/4673436
if (!String.format) {
    String.format = function(format) {
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/{(\d+)}/g, function(match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}

// https://stackoverflow.com/a/18234317
String.prototype.formatUnicorn = function () {
    "use strict";
    var str = this.toString();
    if (arguments.length) {
        var args = typeof arguments[0] === "object" ? arguments[0] : arguments;
        for (var key in args) {
            str = str.replace(new RegExp("\\{" + key + "\\}", "gi"), args[key]);
        }
    }
    return str;
};

String.prototype.append = function(w) {
    return this.endsWith(w) ? this : this + w;
}

String.prototype.prepend = function(w) {
    return this.startsWith(w) ? this : w + this;
}

String.prototype.rtrim = function(s) {
    return this.replace(new RegExp("[" + (s || '\\s') + "]*$"), '');
}

String.prototype.ltrim = function(s) {
    return this.replace(new RegExp("^[" + (s || '\\s') + "]*"), '');
}

String.prototype.mayBeFillHost = function(host) {
    var url = this.trim();
    if (!url) return '';
    if (url.startsWith(host)) return url;
    if (url.startsWith('//')) return host.split('//')[0] + url;

    return host.rtrim('/') + '/' + url.ltrim('/');
}

// --------------------------------------------------

var TypeChecker = {
    isString: function(o) {
        return typeof o === "string" || (typeof o === "object" && o.constructor === String);
    },
    isNumber: function(o) {
        return typeof o === "number" || (typeof o === "object" && o.constructor === Number);
    },
    isArray: function(o) {
        return Array.isArray(o);
    },
    isFunction: function(o) {
        return typeof o === "function";
    },
    isObject: function(o) {
        return typeof o === 'object' && o !== null && !Array.isArray(o);
    }
};

// --------------------------------------------------

function log(o, msg) {
    console.log('___' + (msg || '') + '___');
    if (TypeChecker.isArray(o)) {
        console.log(JSON.stringify(o, null, 2));
    } else {
        console.log(o);
    }
}

function cleanHtml(html) {
    return html
        .replace(/\n/g, '<br>')
        .replace(/(<br>\s*){2,}/gm, '<br>')
        .replace(/<!--[^>]*-->/gm, '')
        .replace(/&nbsp;/g, '')
        .replace(/(^(\s*<br>\s*)+|(<br>\s*)+$)/gm, '')
        .trim();
}

// --------------------------------------------------

var $ = {
    Q: function(e, q, i) {
        var _empty = Html.parse('').select('body');
        var els = e.select(q);
        
        if (!els || els.size() === 0) return _empty;
        if (i === undefined) return els.first();
        
        if (TypeChecker.isNumber(i)) {
            return i === -1 ? els.last() : (i >= els.size() ? _empty : els.get(i));
        } 
        
        if (i.remove) {
            els.select(i.remove).remove();
        }
        return els;
    },
    QA: function(e, q, o = {}) {
        var arr = [];
        var els = e.select(q);

        if (!els || els.size() === 0) return o.j ? '' : arr;

        var processItem = function(item) {
            if (o.f) {
                if (o.f(item)) arr.push(o.m ? o.m(item) : item);
            } else {
                arr.push(o.m ? o.m(item) : item);
            }
        }

        if (o.reverse) {
            for (var i = els.size() - 1; i >= 0; i--) {
                processItem(els.get(i));
            }
        } else {
            for (var i = 0; i < els.size(); i++) {
                processItem(els.get(i));
            }
        }

        return o.j ? arr.join(o.j) : arr;
    }
}

