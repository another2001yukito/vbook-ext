//    var host = 'https://www.69shuba.com';
let BASE_URL = 'https://69shuba.me'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}
