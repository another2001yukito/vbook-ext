load('libs.js');
load('config.js');

function execute(url, page) {
    url = BASE_URL + url;

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'div.recentupdate2 > ul > li');
        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            var link = $.Q(e, 'a').attr('href');
            var id, cover;

            var match = link.match(/\/book\/(\d+)\.htm/);
            if (match && match[1]) {
                id = match[1];
                cover = String.format('{0}/fengmian/{1}/{2}/{2}s.jpg', "https://cdn.shucdn.com", Math.floor(id / 1000), id);
            }

            data.push({
                name: $.Q(e, 'a').text().trim(),
                link: resolveUrl(BASE_URL, link),
                cover: cover || '',
                description: $.Q(e, 'a', 1).text().trim(),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }
    return null;
}

function resolveUrl(base, relative) {
    if (relative.startsWith('http')) return relative;
    return base.replace(/\/$/, '') + '/' + relative.replace(/^\//, '');
}
