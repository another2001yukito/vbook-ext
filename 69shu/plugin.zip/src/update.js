load('libs.js');
load('config.js');

function execute(url, page) {
    url = BASE_URL + url;

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'div.recentupdate2 > ul > li');
        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            var link = $.Q(e, 'a').attr('href');
            var cover = '';
            var m, id;

            if ((m = link.match(/book\/(\d+)\.htm/)) && m[1]) {
                id = m[1];
                cover = `https://static.69shuba.com/files/article/image/${Math.floor(id / 1000)}/${id}/${id}s.jpg`;
            }

            data.push({
                name: $.Q(e, 'a').text(),
                link: link,
                cover: cover,
                description: $.Q(e, 'a', 1).text().replace(/第(\d+)章/, "第$1章:").replace(/(?:\d+\.)?第(\d+)章(?:\s*\d+)?/, "第$1章"),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }
    return null;
}