load('libs.js');
load('config.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function execute(url, page) {
    let domain = url.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/i);
    if (!domain) return Response.error("Invalid URL domain");

    domain = "https://" + domain[1];

    if (!BASE_URLS.includes(domain)) return Response.error("Unsupported source");

    url = url.replace(domain, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'div.recentupdate2 > ul > li');
        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            var link = $.Q(e, 'a').attr('href');
            var m, id, cover;

            if ((m = link.match(/\/book\/(\d+)\.htm/)) && m[1] && (id = m[1])) {
                cover = `https://cdn.shucdn.com/fengmian/${Math.floor(id / 1000)}/${id}/${id}s.jpg`;
            }

            data.push({
                name: $.Q(e, 'a').text(),
                link: link.replace(domain, BASE_URL),
                cover: cover || '',
                description: $.Q(e, 'a', 1).text(),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }
    return Response.error("Failed to fetch data");
}
