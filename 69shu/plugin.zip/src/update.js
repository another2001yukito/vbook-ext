load('libs.js');
load('config.js');

const BASE_URLS = ["https://69shuba.cx", "https://69shuba.com", "https://69shuba.me"];

function getAvailableBaseUrl() {
    for (let url of BASE_URLS) {
        let response = fetch(url + "/favicon.ico");
        if (response.ok) return url;
    }
    return BASE_URLS[0];
}

const BASE_URL = getAvailableBaseUrl();

function execute(url, page) {
    url = resolveUrl(BASE_URL, url);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'div.recentupdate2 > ul > li');
        if (!elems.length) return Response.error("Không tìm thấy dữ liệu tại: " + url);

        elems.forEach(function(e) {
            var link = $.Q(e, 'a').attr('href');
            var id, cover;

            var match = link.match(/\/book\/(\d+)\.htm/);
            if (match && match[1]) {
                id = match[1];
                cover = `https://cdn.shucdn.com/fengmian/${Math.floor(id / 1000)}/${id}/${id}s.jpg`;
            }

            data.push({
                name: $.Q(e, 'a').text().trim(),
                link: resolveUrl(BASE_URL, link),
                cover: cover || '',
                description: $.Q(e, 'a', 1).text().trim(),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }
    return Response.error("Không thể tải trang: " + url);
}

function resolveUrl(base, relative) {
    if (relative.startsWith('http')) return relative;
    return base.replace(/\/$/, '') + '/' + relative.replace(/^\//, '');
}
