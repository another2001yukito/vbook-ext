load('libs.js');
load('config.js');

function execute(url, page) {
    url = BASE_URL + url;

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];

        var elems = $.QA(doc, 'div.recentupdate2 > ul > li');
        if (!elems.length) return Response.error(url);

        elems.forEach(function(e) {
            let link = $.Q(e, 'a').attr('href');
            let idMatch = link.match(/\/book\/(\d+)\.htm/);
            let cover = '';

            if (idMatch && idMatch[1]) {
                let id = idMatch[1];
                let prefix = Math.floor(id / 1000);
                cover = String.format('https://69shuba.cx/fengmian/{0}/{1}/{1}s.jpg', prefix, id);

                let coverResponse = fetch(cover, { method: 'HEAD' });
                if (!coverResponse || coverResponse.status !== 200) {
                    cover = 'https://69shuba.cx/cdn/images/nc.jpg';
                }
            }

            data.push({
                name: $.Q(e, 'a').text().trim(),
                link: link,
                cover: cover,
                description: $.Q(e, 'a', 1).text().trim(),
                host: BASE_URL
            });
        });

        return Response.success(data);
    }
    return null;
}
