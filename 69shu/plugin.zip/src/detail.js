load('libs.js');
load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = url.replace("/txt/","/book/")
    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html('gbk');
    let name = $.Q(doc, 'div.booknav2 > h1 > a').text();
    let author = $.Q(doc, 'div.booknav2 > p:first-of-type > a').text().trim();
    let description = $.Q(doc, 'div.jianjie-popup-content.jianjiebox > div.content > p').text();
    let detail = $.QA(doc, 'div.booknav2 p', {m: x => x.text(), j: '<br>'});

    let cover;
    if (BASE_URL.includes("69shuba.com") || BASE_URL.includes("69shuba.me")) {
        cover: $.Q(doc, 'div.bookimg2 > img').attr('src');
    } else {
        let bookLink = $.Q(doc, 'div.booknav2 > h1 > a').attr('href');
        let match = bookLink ? bookLink.match(/\/book\/(\d+)\.htm/) : null;
        let bookId = match ? parseInt(match[1]) : null;

        cover = bookId 
            ? `${BASE_URL}/fengmian/${Math.floor(bookId / 1000)}/${bookId}/${bookId}s.jpg`
            : '';
    }

    return Response.success({ name, cover, author, description, detail, host: BASE_URL });
}