load('libs.js');
load('config.js');

function execute(url, page) {
    page = page || '1';
    // Construct the genre URL
    url = String.format(BASE_URL + "/blist/tag/" + url + (page === '1' ? '/' : '/' + page + '/'));
    console.log(url);
    
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];
        var elems = $.QA(doc, '.newnav');
        
        if (!elems.length) return Response.error(url);
        
        elems.forEach(function(e) {
            let bookId = $.Q(e, 'h3 > a').attr('href').match(/(\d+)\.htm/)[1];
            let prefix = Math.floor(bookId / 1000);
            let coverUrl = String.format('https://69shuba.cx/fengmian/{0}/{1}/{1}s.jpg', prefix, bookId);

            // Extract the genre tags from the page
            let genreTags = [];
            let genreElements = $.QA(doc, '.tagul a', {m: x => x.text().trim(), j: ' | '});
            genreTags = genreElements;

            // Prepare the data for each book
            data.push({
                name: $.Q(e, 'h3 > a').text().trim(),
                cover: coverUrl,
                description: $.Q(e, '.ellipsis_2').text().trim() || "No description available",
                genre: genreTags.join(', '),  // Join genres if there are multiple
                genreLinks: genreElements.map(tag => BASE_URL + tag), // Adding genre links
                host: BASE_URL
            });
        });
        
        var next = parseInt(page, 10) + 1;
        return Response.success(data, next.toString());
    }
    return null;
}
