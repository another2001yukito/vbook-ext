load('libs.js');
load('config.js');

function execute(url) {
    // Extract the book ID from the URL
    let bookIdMatch = url.match(/\/b\/(\d+)/);
    if (!bookIdMatch) {
        return null; // Return null if the book ID cannot be found
    }
    
    let bookId = bookIdMatch[1]; // Get the book ID from the match

    // Modify the URL
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = url.replace("/txt/", "/book/");
    
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html('gbk');

        // Determine the cover image URL based on the book ID length
        let cover;
        if (bookId.length === 5) {
            cover = `https://69shuba.cx/bimages/${bookId.substring(0, 2)}/${bookId}/${bookId}s.jpg`; // 5-digit ID
        } else if (bookId.length === 4) {
            cover = `https://69shuba.cx/bimages/${bookId.charAt(0)}/${bookId}/${bookId}s.jpg`; // 4-digit ID
        } else {
            cover = ''; // Fallback to an empty string if the ID is not valid
        }

        return Response.success({
            name: $.Q(doc, 'div.booknav2 > h1 > a').text(),
            cover: cover,
            author: $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text().trim(),
            description: $.Q(doc, 'div.navtxt > p').html(),
            detail: $.QA(doc, 'div.booknav2 p', {m: x => x.text(), j: '<br>'}),
            host: BASE_URL
        });
    }
    
    return null;
}
