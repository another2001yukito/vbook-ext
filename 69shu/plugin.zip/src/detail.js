load('libs.js');
load('config.js');

function execute(url) {
    if (BASE_URL.includes("69shuba.cx")) {
        url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
        url = url.replace("/c/", "/b/");

        let response = fetch(url);
        if (response.ok) {
            let doc = response.html('gbk');

            let coverLink = $.Q(doc, 'div.booknav2 > h1 > a').attr('href');
            let bookIdMatch = coverLink ? coverLink.match(/\/book\/(\d+)\.htm/) : null;
            let bookId = bookIdMatch ? bookIdMatch[1] : null;

            let coverImage = bookId 
                ? String.format('{0}/fengmian/{1}/{2}/{3}s.jpg', BASE_URL, Math.floor(bookId / 1000), bookId, bookId) 
                : '';

            return Response.success({
                name: $.Q(doc, 'div.booknav2 > h1 > a').text(),
                cover: coverImage,
                author: $.Q(doc, 'div.booknav2 > p:first-of-type > a').text().trim(),
                description: $.Q(doc, 'div.jianjie-popup-content.jianjiebox > div.content > p').text(),
                detail: $.QA(doc, 'div.booknav2 p', {m: x => x.text(), j: '<br>'}),
                host: BASE_URL
            });
        }
    } else if (BASE_URL.includes("69shuba.com") || BASE_URL.includes("69shuba.me")) {
        url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
        url = url.replace("/txt/", "/book/");

        let response = fetch(url);
        if (response.ok) {
            let doc = response.html('gbk');

            return Response.success({
                name: $.Q(doc, 'div.booknav2 > h1 > a').text(),
                cover: $.Q(doc, 'div.bookimg2 > img').attr('src'),
                author: $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text().trim(),
                description: $.Q(doc, 'div.navtxt > p').html(),
                detail: $.QA(doc, 'div.booknav2 p', {m: x => x.text(), j: '<br>'}),
                host: BASE_URL
            });
        }
    }
    return null;
}
