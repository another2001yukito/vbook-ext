load('libs.js');
load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    url = url.replace("/c/","/b/");

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html('gbk');
        
        // Extract the book ID from the href attribute
        let coverLink = $.Q(doc, 'div.booknav2 > h1 > a').attr('href');
        let bookId = coverLink.match(/\/book\/(\d+)\.htm/); // Extracting the numeric ID from the link
        
        // If a valid book ID is found, form the correct cover URL
        let coverImage = bookId ? `https://69shuba.cx/fengmian/${bookId[1].slice(0, 2)}/${bookId[1]}/${bookId[1]}s.jpg` : ''; 
        
        return Response.success({
            name: $.Q(doc, 'div.booknav2 > h1 > a').text(),
            cover: coverImage,  // Updated cover URL
            author: $.Q(doc, 'div.booknav2 > p:first-of-type > a').text().trim(),
            description: $.Q(doc, 'div.jianjie-popup-content.jianjiebox > div.content > p').text(),
            detail: $.QA(doc, 'div.booknav2 p', {m: x => x.text(), j: '<br>'}),
            host: BASE_URL
        });
    }
    return null;
}
