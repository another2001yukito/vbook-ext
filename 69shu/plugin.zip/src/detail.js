// detail.js — Lấy thông tin chi tiết truyện
//
// Cấu trúc HTML thực tế (trang /book/XXXXX.htm):
// <div class="bookimg2"><img src="...cover..."></div>
// <div class="booknav2">
//   <h1><a href="...">Tên truyện</a></h1>
//   <p>作者：<a href="...">Tên tác giả</a></p>
//   <p>分类：<a href="...">Thể loại</a></p>
//   <p>XXXXX万字 | 连载</p>
//   <p>更新：YYYY-MM-DD</p>
// </div>
// <div class="navtxt"><p>Mô tả...</p></div>

load('config.js');
load('libs.js');

function execute(url) {
    // Chuẩn hoá URL: luôn dùng /book/XXXXX.htm
    // Nếu là /txt/XXXXX/... thì extract book ID và chuyển sang /book/
    url = normalizeToBookUrl(url);

    var response = fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    if (!response.ok) return Response.error('Fetch failed: ' + url);

    var doc = response.html('gbk');

    var name   = $.Q(doc, 'div.booknav2 > h1 > a').text().trim();
    var cover  = $.Q(doc, 'div.bookimg2 > img').attr('src') || '';
    var author = $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text().trim();
    var desc   = $.Q(doc, 'div.navtxt > p').html() || '';

    // detail: ghép tất cả <p> trong booknav2
    var detailParts = [];
    $.QA(doc, 'div.booknav2 p').forEach(function(p) {
        var t = p.text().trim();
        if (t) detailParts.push(t);
    });
    var detail = detailParts.join('<br>');

    // Kiểm tra trạng thái: "连载" = đang ra, "完结"/"完本" = hoàn thành
    var navText = $.Q(doc, 'div.booknav2').text();
    var ongoing = navText.indexOf('连载') !== -1;

    if (!name) return Response.error('Cannot parse book info from: ' + url);

    return Response.success({
        name:        name,
        cover:       cover,
        host:        BASE_URL,
        author:      author,
        description: desc,
        detail:      detail,
        ongoing:     ongoing
    });
}

// Chuyển mọi dạng URL sang /book/XXXXX.htm
function normalizeToBookUrl(url) {
    var m = url.match(/\/(?:book|txt)\/(\d+)/);
    if (m) return BASE_URL + '/book/' + m[1] + '.htm';
    return url.replace(/^https?:\/\/[^\/]+/, BASE_URL);
}
