load('libs.js');
load('config.js');

function execute(url) {
    url = url.replace("/txt/", "/book/");

    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html('gbk');

    let name = $.Q(doc, 'div.booknav2 > h1 > a').text().trim();
    let author = $.Q(doc, 'div.booknav2 > p:first-of-type > a').text().trim();
    let description = $.Q(doc, 'div.navtxt > p').text().trim();
    let detail = $.QA(doc, 'div.booknav2 p', { m: x => x.text().trim(), j: '<br>' });
    let cover = $.Q(doc, 'div.bookimg2 img').attr('src') || '';

    return Response.success({ name, cover, author, description, detail, host: BASE_URL });
}