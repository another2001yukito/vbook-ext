// genlist.js — Parser danh sách truyện chung
// Dùng cho: home tabs, genre tabs
//
// Cấu trúc HTML thực tế:
// <div class="newbox">
//   <ul>
//     <li>
//       <a class="imgbox" href="...">
//         <img data-src="...">
//       </a>
//       <div class="newnav">
//         <h3><a href="...">Tên truyện</a></h3>   ← dùng a:not([class]) để tránh label
//         <div class="zxzj"><p><span>最近章节</span>Chương mới nhất</p></div>
//       </div>
//     </li>
//   </ul>
// </div>

load('config.js');
load('libs.js');

function execute(url, page) {
    page = page || '1';
    var fullUrl = BASE_URL + String.format(url, page);

    var response = fetch(fullUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    if (!response.ok) return Response.error('Fetch failed: ' + fullUrl);

    var doc = response.html('gbk');
    var data = [];

    var items = $.QA(doc, '.newbox li');
    if (!items.length) return Response.error('No items found at: ' + fullUrl);

    items.forEach(function(li) {
        // Tên truyện: a:not([class]) để tránh bắt label/badge
        var nameEl  = $.Q(li, '.newnav h3 > a:not([class])');
        var linkEl  = $.Q(li, 'h3 > a');
        var coverEl = $.Q(li, '.imgbox > img');
        var descEl  = $.Q(li, '.zxzj > p');

        var name  = nameEl.text().trim();
        var link  = linkEl.attr('href');
        var cover = coverEl.attr('data-src') || coverEl.attr('src') || '';
        var desc  = descEl.text()
                        .replace('最近章节', '')
                        .trim();

        if (name && link && link.startsWith('http')) {
            data.push({
                name:        name,
                link:        link,
                cover:       cover.trim(),
                description: desc,
                host:        BASE_URL
            });
        }
    });

    var next = (parseInt(page, 10) + 1).toString();
    return Response.success(data, next);
}
