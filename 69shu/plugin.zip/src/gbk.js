// GBK encoder — dùng để encode từ khoá tìm kiếm trước khi gửi lên server
// Source: https://www.programmersought.com/article/94595090520/
var GBK = (function() {
    var data = (function(zipData) {
        var re = zipData
            .replace(/#(\d+)\$/g, function(a, b) {
                return Array(+b + 3).join('#');
            })
            .replace(/#/g, '####')
            .replace(/(\w\w):([\w#]+)(?:,|$)/g, function(a, hd, dt) {
                return dt.replace(/../g, function(a) {
                    return a !== '##' ? hd + a : a;
                });
            });
        return re;
    })('4e:020405060f12171f20212326292e2f313335373c40414244464a5155575a5b6263646567686a6b6c6d6e6f727475767778797a7b7c7d7f808182838485878a#909697999c9d9ea3aaafb0b1b4b6b7b8b9bcbdbec8cccfd0d2dadbdce0e2e6e7e9edeeeff1f4f8f9fafcfe,4f:00020304050607080b0c12131415161c1d212328292c2d2e31333537393b3e3f40414244454748494a4b4c525456616266686a6b6d6e7172757778797a7d8081828586878a8c8e909293959698999a9c9e9fa1a2a4abadb0b1b2b3b4b6b7b8b9babbbcbdbec0c1c2c6c7c8c9cbcccdd2d3d4d5d6d9dbe0e2e4e5e7ebecf0f2f4f5f6f7f9fbfcfdff,50:000102030405060708090a#0b0e1011131516171b1d1e20222324272b2f303132333435363738393b3d3f404142444546494a4b4d5051525354565758595b5d5e5f6061626364666768696a6b6d6e6f70717273747578797a7c7d818283848687898a8b8c8e8f909192939495969798999a9b9c9d9e9fa0a1a2a4a6aaabadaeafb0b1b3b4b5b6b7b8b9bcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdced0d1d2d3d4d5d7d8d9dbdcdddedfe0e1e2e3e4e5e8e9eaebeff0f1f2f4f6f7f8f9fafcfdfeff');

    var U2Ghash = {}, G2Uhash = {};

    (function(data) {
        var k = 0;
        data = data.match(/..../g);
        for (var i = 0x81; i <= 0xfe; i++) {
            for (var j = 0x40; j <= 0xFE; j++) {
                U2Ghash[data[k++]] = ('%' + i.toString(16) + '%' + j.toString(16)).toUpperCase();
            }
        }
        for (var key in U2Ghash) {
            G2Uhash[U2Ghash[key]] = key;
        }
    })(data);

    function isAscii(code) {
        return (code === 0x20AC) || (code >= 0x0000 && code <= 0x007F);
    }

    return {
        encode: function(str) {
            return str.replace(/./g, function(a) {
                var code = a.charCodeAt(0);
                if (isAscii(code)) return encodeURIComponent(a);
                var key = code.toString(16);
                if (key.length !== 4) key = ('000' + key).match(/....$/)[0];
                return U2Ghash[key] || a;
            });
        }
    };
})();
