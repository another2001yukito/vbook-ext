// search.js — Tìm kiếm truyện
//
// Endpoint: POST /modules/article/search.php
//   params: searchkey=GBK_ENCODED, searchtype=all
//
// Quan sát từ HTML thực tế:
//   - Khi search trả nhiều kết quả → cấu trúc .newbox li (giống genlist)
//   - Khi search trả 1 kết quả → server redirect sang trang detail (booknav2)
//   - Khi không có kết quả → chỉ hiển thị form search (error-text)
//
// Lưu ý: searchkey phải encode GBK trước khi gửi

load('config.js');
load('libs.js');
load('gbk.js');

function execute(key, page) {
    if (!key || !key.trim()) return Response.error('Thiếu từ khoá tìm kiếm');

    var encodedKey = GBK.encode(key.trim());
    var url = BASE_URL + '/modules/article/search.php';

    var response = fetch(url, {
        method: 'POST',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36',
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: {
            searchkey: encodedKey,
            searchtype: 'all'
        }
    });

    if (!response.ok) return Response.error('Fetch failed: ' + url);

    var doc = response.html('gbk');
    var data = [];

    // Trường hợp 1: nhiều kết quả — .newbox li
    var items = $.QA(doc, '.newbox li');
    if (items.length > 0) {
        items.forEach(function(li) {
            var nameEl  = $.Q(li, '.newnav h3 > a:not([class])');
            var linkEl  = $.Q(li, 'h3 > a');
            var coverEl = $.Q(li, '.imgbox > img');
            var descEl  = $.Q(li, '.zxzj > p');

            var name  = nameEl.text().trim();
            var link  = linkEl.attr('href');
            var cover = (coverEl.attr('data-src') || coverEl.attr('src') || '').trim();
            var desc  = descEl.text().replace('最近章节', '').trim();

            if (name && link) {
                data.push({
                    name:        name,
                    link:        link.startsWith('http') ? link : BASE_URL + link,
                    cover:       cover,
                    description: desc,
                    host:        BASE_URL
                });
            }
        });
        if (data.length > 0) return Response.success(data);
    }

    // Trường hợp 2: kết quả đơn — redirect sang trang detail
    var singleName = $.Q(doc, 'div.booknav2 > h1 > a');
    if (singleName.text().trim()) {
        var link  = singleName.attr('href');
        var cover = $.Q(doc, 'div.bookimg2 > img').attr('src') || '';
        var auth  = $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text().trim();

        return Response.success([{
            name:        singleName.text().trim(),
            link:        link.startsWith('http') ? link : BASE_URL + link,
            cover:       cover,
            description: auth,
            host:        BASE_URL
        }]);
    }

    return Response.error('Không tìm thấy kết quả cho: ' + key);
}
