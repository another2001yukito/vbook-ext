load('libs.js');
load('config.js');
load('gbk.js');

function execute(key, page) {
    if (!key) return Response.error("Search key is missing");

    var encodedKey = GBK.encode(key);
    var url = `${host}/modules/article/search.php?searchkey=${encodedKey}&searchtype=all`;

    let response = fetch(url);
    if (!response.ok) {
        return Response.error("Failed to fetch search results");
    }

    let doc = response.html('gbk');
    let data = [];

    let elems = $.QA(doc, '.newbox li');
    if (elems.length > 0) {
        elems.forEach(e => {
            data.push({
                name: $.Q(e, '.newnav h3 > a:not([class])').text().trim(),
                link: $.Q(e, '.newnav > a').attr('href'),
                cover: $.Q(e, '.imgbox > img').attr('data-src')?.trim() || '',
                description: $.Q(e, '.zxzj > p').text().replace('最近章节', '').trim(),
                host: BASE_URL
            });
        });
        return Response.success(data);
    }

    let singleMatch = $.Q(doc, 'div.booknav2 > h1 > a');
    if (singleMatch.text()) {
        return Response.success([{
            name: singleMatch.text(),
            link: singleMatch.attr('href'),
            cover: $.Q(doc, 'div.bookimg2 > img').attr('src') || '',
            description: $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text().trim(),
            host: BASE_URL
        }]);
    }

    return Response.error(`No results found for "${key}"`);
}