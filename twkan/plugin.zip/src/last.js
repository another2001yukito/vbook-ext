// last.js — danh sách "最近更新" (cập nhật gần đây), không phân trang
//
// <div class="recentupdate2"><ul>
//   <li>
//     <a href="/book/ID.html">Tên truyện</a>
//     <a href="/txt/ID/CHAP_ID">Tên chương mới nhất</a>
//     <span>Ngày cập nhật</span>
//   </li>
// </ul></div>
//
// Trang này không có ảnh bìa sẵn trong HTML — dựng bằng coverUrl() (libs.js)
// từ book ID lấy trong link.

load('config.js');
load('libs.js');

function execute() {
    var response = fetch(BASE_URL + '/last', {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });
    if (!response.ok) {
        return Response.error('Load failed: ' + BASE_URL + '/last');
    }

    var doc = response.html();
    var data = [];

    $.QA(doc, '.recentupdate2 li').forEach(function(li) {
        var links = $.QA(li, 'a');
        if (links.length < 1) return;
        var name = (links[0].text() + '').trim();
        var link = links[0].attr('href') + '';
        if (!name || !link) return;

        var chapterName = links[1] ? (links[1].text() + '').trim() : '';
        var bookId = extractBookId(link);

        data.push({
            name: name,
            link: link.startsWith('http') ? link : BASE_URL + link,
            cover: bookId ? coverUrl(bookId) : '',
            description: chapterName,
            host: BASE_URL
        });
    });

    if (!data.length) {
        return Response.error('No items found: ' + BASE_URL + '/last');
    }

    return Response.success(data);
}
