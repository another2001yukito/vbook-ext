load('config.js');
load('libs.js');

function execute(url) {
    var bookId = extractBookId(url);
    if (!bookId) {
        return Response.error('Cannot extract book ID: ' + url);
    }

    var ajaxUrl = BASE_URL + '/ajax_novels/chapterlist/' + bookId + '.html';
    var response = fetch(ajaxUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });
    if (!response.ok) {
        return Response.error('Load failed: ' + ajaxUrl);
    }

    var doc = response.html();
    var data = [];

    $.QA(doc, 'ul > li > a').forEach(function(a) {
        var href = a.attr('href') + '';
        var name = (a.text() + '').trim();
        if (!href || href.indexOf('/txt/') === -1 || !name) return;
        data.push({
            name: name,
            url: href.startsWith('http') ? href : BASE_URL + href,
            host: BASE_URL
        });
    });

    if (!data.length) {
        return Response.error('No chapters found: ' + ajaxUrl);
    }

    return Response.success(data);
}