load('config.js');
load('libs.js');

function execute(url, page) {
    if (!page) page = '1';
    var fullUrl = BASE_URL + String.format(url, page);
    var response = fetch(fullUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    if (!response.ok) {
        return Response.error('Load failed: ' + fullUrl);
    }

    var doc = response.html();
    var data = [];

    $.QA(doc, '#article_list_content li, .newbox li').forEach(function(item) {
        var nameEl = $.Q(item, 'h3 a:not([class])');
        var name = (nameEl.text() + '').trim();
        var link = nameEl.attr('href') + '';
        if (!name || !link) return;

        var coverEl = $.Q(item, 'a.imgbox img, .imgbox img');
        var cover = (coverEl.attr('data-src') + '') || (coverEl.attr('src') + '');

        var labels = $.QA(item, '.labelbox label');
        var author = labels[0] ? (labels[0].text() + '').trim() : '';

        var descEl = $.Q(item, '.zxzj > p');
        var desc = (descEl.text() + '').replace('最近章節', '').trim();
        if (!desc) desc = ($.Q(item, 'ol.ellipsis_2').text() + '').trim();

        data.push({
            name: name,
            link: link.startsWith('http') ? link : BASE_URL + link,
            cover: cover,
            description: desc || author,
            host: BASE_URL
        });
    });

    if (!data.length) {
        return Response.error('No items found: ' + fullUrl);
    }

    if (url.indexOf('{0}') === -1) {
        return Response.success(data);
    }
    var next = (parseInt(page, 10) + 1).toString();
    return Response.success(data, next);
}