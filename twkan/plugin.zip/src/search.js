load('config.js');
load('libs.js');

function execute(key, page) {
    if (!page) page = '1';
    var searchUrl = BASE_URL + '/search/' + encodeURIComponent(key.trim()) + '/' + page + '.html';
    var response = fetch(searchUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    if (!response.ok) {
        return Response.error('Search failed: ' + searchUrl);
    }

    var doc = response.html();
    var data = [];

    $.QA(doc, '#article_list_content li, .newbox li').forEach(function(item) {
        var nameEl = $.Q(item, 'h3 a:not([class])');
        var name = (nameEl.text() + '').trim();
        var link = nameEl.attr('href') + '';
        if (!name || !link) return;

        var coverEl = $.Q(item, 'a.imgbox img, .imgbox img');
        var cover = (coverEl.attr('data-src') + '') || (coverEl.attr('src') + '');

        var labels = $.QA(item, '.labelbox label');
        var author = labels[0] ? (labels[0].text() + '').trim() : '';

        var descEl = $.Q(item, '.zxzj > p');
        var desc = (descEl.text() + '').replace('最近章節', '').trim();
        if (!desc) desc = ($.Q(item, 'ol.ellipsis_2').text() + '').trim();

        data.push({
            name: name,
            link: link.startsWith('http') ? link : BASE_URL + link,
            cover: cover,
            description: desc || author,
            host: BASE_URL
        });
    });

    if (data.length) {
        return Response.success(data);
    }

    var singleName = ($.Q(doc, 'div.booknav2 > h1 > a').text() + '').trim();
    if (singleName) {
        var link = $.Q(doc, 'div.booknav2 > h1 > a').attr('href') + '';
        var cover = $.Q(doc, 'div.bookimg2 > img').attr('src') + '';
        return Response.success([{
            name: singleName,
            link: link.startsWith('http') ? link : BASE_URL + link,
            cover: cover,
            description: extractAuthor(doc),
            host: BASE_URL
        }]);
    }

    return Response.error(key);
}