load('libs.js');
load('config.js');

var CATEGORIES = [
    { id: 0,  name: '全部分類' },
    { id: 1,  name: '玄幻奇幻' },
    { id: 2,  name: '武俠仙俠' },
    { id: 3,  name: '現代都市' },
    { id: 4,  name: '歷史軍事' },
    { id: 5,  name: '科幻小說' },
    { id: 6,  name: '遊戲競技' },
    { id: 7,  name: '恐怖靈異' },
    { id: 8,  name: '言情小說' },
    { id: 9,  name: '動漫同人' },
    { id: 10, name: '其他類型' }
];

function execute() {
    var data = [{
        title: '最近更新',
        input: '/last',
        script: 'last.js'
    }];
    CATEGORIES.forEach(function(c) {
        data.push({
            title: c.name,
            input: '/novels/class/' + c.id + '_{0}.html',
            script: 'genlist.js'
        });
    });
    return Response.success(data);
}