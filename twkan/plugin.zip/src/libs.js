if (!String.format) {
    String.format = function(format) {
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/{(\d+)}/g, function(match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}

var $ = {
    Q: function(el, selector) {
        var found = el.select(selector);
        if (found && found.size && found.size() > 0) return found.first();
        return Html.parse('').select('body');
    },
    QA: function(el, selector) {
        var found = el.select(selector);
        var arr = [];
        if (found) {
            for (var i = 0; i < found.size(); i++) arr.push(found.get(i));
        }
        return arr;
    }
};

function metaContent(doc, property) {
    return $.Q(doc, 'meta[property="' + property + '"]').attr('content') + '';
}

function coverUrl(bookId) {
    var id = String(bookId);
    var prefix = id.length > 3 ? id.substring(0, id.length - 3) : id;
    return BASE_URL + '/files/article/image/' + prefix + '/' + id + '/' + id + 's.jpg';
}

function extractBookId(url) {
    var m = (url + '').match(/\/(?:book|txt)\/(\d+)/);
    return m ? m[1] : null;
}

function extractAuthor(doc) {
    var metaAuthor = metaContent(doc, 'og:novel:author').trim();
    if (metaAuthor) return metaAuthor;
    var navText = $.Q(doc, 'div.booknav2').text() + '';
    var m = navText.match(/作者[:：]\s*(\S+)/);
    return m ? m[1].trim() : '';
}

function extractDescription(doc) {
    var metaDesc = metaContent(doc, 'og:description').trim();
    if (metaDesc) return metaDesc;
    return $.Q(doc, 'div.navtxt > p').html() + '';
}

var ALLOWED_CHARS = /^[\u0000-\u007F\u2000-\u206F\u3000-\u303F\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF\u00B7\u00B0\u2027\u30FB\s]*$/;

var AD_PHRASES = [
    /本書由全網首發/,
    /記住首發網站域名/,
    /[台臺]灣小[說説]網/,
    /提供給?你無錯章節/,
    /觀看最快的章節更新/,
    /積極分享本站域名/,
    /本小章还未完，请点击下一页继续阅读后面精彩内容！/,
    /这章没有结束，请点击下一页继续阅读！/,
    /章没有结束，请点击下一页继续阅读！/
];

var MAX_AD_LINE_LENGTH = 120;

function isAdLine(line) {
    var s = line.trim();
    if (!s) return false;
    if (s.length <= MAX_AD_LINE_LENGTH && !ALLOWED_CHARS.test(s)) return true;
    for (var i = 0; i < AD_PHRASES.length; i++) {
        if (AD_PHRASES[i].test(s)) return true;
    }
    return false;
}

function cleanHtml(html) {
    var text = (html + '')
        .replace(/\r\n|\r/g, '\n')
        .replace(/<!--[\s\S]*?-->/g, '')
        .replace(/\n/g, '<br>')
        .replace(/(<br>\s*){2,}/gi, '<br>')
        .replace(/&nbsp;/g, ' ')
        .replace(/&gt;/g, '')
        .replace(/&lt;/g, '');

    return text
        .split(/<br\s*\/?>/i)
        .filter(function(line) { return !isAdLine(line); })
        .join('<br>');
}