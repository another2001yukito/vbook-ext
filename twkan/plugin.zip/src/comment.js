load('config.js');
load('libs.js');

function execute(input) {
    var response = fetch(input, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });
    if (!response.ok) {
        return Response.error('Load failed: ' + input);
    }
    var doc = response.html();
    var comments = [];

    $.QA(doc, '.review-item').forEach(function(item) {
        var name = ($.Q(item, '.user strong').text() + '').trim();
        var content = ($.Q(item, '.review-text').text() + '').trim();
        var values = $.QA(item, '.c_tag .c_value');
        var time = values[0] ? (values[0].text() + '').trim() : '';

        if (name && content) {
            comments.push({ name: name, content: content, description: time });
        }
    });

    return Response.success(comments);
}