load('config.js');
load('libs.js');

function execute(url) {
    if (!url.startsWith('http')) {
        url = BASE_URL + (url.startsWith('/') ? url : '/' + url);
    }

    var response = fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });

    var doc;
    if (!response.ok) {
        var browser = Engine.newBrowser();
        try {
            browser.setUserAgent(UserAgent.android());
            doc = browser.launch(url, 5000);
        } finally {
            browser.close();
        }
        if (!doc || (doc.html() + '').length < 200) {
            return Response.error('Load failed: ' + url);
        }
    } else {
        doc = response.html();
    }

    var block = doc.select('#txtcontent0');
    if (!block || (block.html() + '').trim() === '') {
        block = doc.select('#txtcontent');
        if (!block || (block.html() + '').trim() === '') {
            block = doc.select('.txtnav, .content, #content');
            if (!block || (block.html() + '').trim() === '') {
                return Response.error('Content block not found: ' + url);
            }
        }
    }

    var content = cleanHtml(block.html() + '')
        .replace(/^[\s\u2003]*第\d+章[^<]*(<br>\s*)?/, '')
        .replace(/^\s*\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s*作者[:：]\s*[^\s<]*(<br>\s*)?/, '')
        .trim();

    if (!content) {
        return Response.error('Empty content: ' + url);
    }

    return Response.success(content);
}