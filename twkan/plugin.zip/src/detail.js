load('config.js');
load('libs.js');

function execute(url) {
    var response = fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36' }
    });
    if (!response.ok) {
        return Response.error('Load failed: ' + url);
    }
    var doc = response.html();

    var name   = metaContent(doc, 'og:novel:book_name').trim() || ($.Q(doc, 'div.booknav2 > h1 > a').text() + '').trim();
    var cover  = metaContent(doc, 'og:image').trim() || (($.Q(doc, 'div.bookimg2 > img').attr('data-src') + '') || ($.Q(doc, 'div.bookimg2 > img').attr('src') + ''));
    var author = extractAuthor(doc);
    var desc   = extractDescription(doc) || '';

    var detailParts = [];
    $.QA(doc, 'div.booknav2 p').forEach(function(p) {
        var t = (p.text() + '').trim();
        if (t) detailParts.push(t);
    });
    var detail = detailParts.join('<br>');

    var statusText = metaContent(doc, 'og:novel:status').trim() || ($.Q(doc, 'div.booknav2').text() + '');
    var ongoing = statusText.indexOf('完') === -1;

    var bookinfoText = '';
    $.QA(doc, 'script').forEach(function(s) {
        if (bookinfoText) return;
        var t = s.html() + '';
        if (t.indexOf('var bookinfo') !== -1) bookinfoText = t;
    });
    var tagsMatch = bookinfoText.match(/tags:\s*'([^']*)'/);
    var tagNames = tagsMatch
        ? tagsMatch[1].split(',').map(function(t) { return t.trim(); }).filter(function(t) { return t; })
        : [];

    var authorEl = $.Q(doc, 'div.booknav2 a[href*="/author/"]');
    var authorHref = authorEl.attr('href') + '';
    var genreCatEl = $.Q(doc, 'div.booknav2 a[href*="/novels/class/"]');
    var genreCatName = (genreCatEl.text() + '').trim();
    var genreCatHref = genreCatEl.attr('href') + '';

    var genres = [];
    if (genreCatName && genreCatHref) {
        var genreCatInput = (genreCatHref.indexOf('http') === 0 ? genreCatHref.replace(BASE_URL, '') : genreCatHref)
            .replace(/_\d+\.html$/, '_{0}.html');
        genres.push({ title: genreCatName, input: genreCatInput, script: 'genlist.js' });
    }
    tagNames.forEach(function(t) {
        genres.push({ title: t, input: '/newtag/' + t + '/{0}', script: 'genlist.js' });
    });

    var suggests = [];
    if (author && authorHref) {
        var authorInput = authorHref.indexOf('http') === 0 ? authorHref.replace(BASE_URL, '') : authorHref;
        suggests.push({ title: 'Cùng tác giả', input: authorInput, script: 'genlist.js' });
    }

    var score = 0, scoreMax = 0;
    $.QA(doc, 'script').forEach(function(s) {
        if (scoreMax) return;
        var m = (s.html() + '').match(/showRating\((\d+),\s*([\d.]+)/);
        if (m) {
            scoreMax = parseFloat(m[1]);
            score = parseFloat(m[2]);
        }
    });

    if (!name) {
        return Response.error('Book not found: ' + url);
    }

    return Response.success({
        name:        name,
        cover:       cover,
        host:        BASE_URL,
        author:      author,
        description: desc,
        detail:      detail,
        ongoing:     ongoing,
        genres:      genres,
        suggests:    suggests,
        score:       score,
        scoreMax:    scoreMax,
        comments: [{
            title:  'Bình luận',
            input:  url,
            script: 'comment.js'
        }]
    });
}